#!/bin/sh
cd "$(dirname "$0")"
# npm init -y
npm i express
npm i @yumdocs/yumdocs