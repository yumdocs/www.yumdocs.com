#!/bin/sh
cd "$(dirname "$0")"
yumdocs input.docx data.json output.docx