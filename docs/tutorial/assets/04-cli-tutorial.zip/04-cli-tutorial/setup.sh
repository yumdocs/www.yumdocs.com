#!/bin/sh
cd "$(dirname "$0")"
npm i -g @yumdocs/yumdocs-cli