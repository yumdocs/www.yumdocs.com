#!/bin/sh
cd "$(dirname "$0")"
npm i @yumdocs/yumdocs