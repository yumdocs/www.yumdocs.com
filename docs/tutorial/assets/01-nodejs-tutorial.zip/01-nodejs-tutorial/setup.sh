#!/bin/sh
cd "$(dirname "$0")"
# npm init -y
npm i @yumdocs/yumdocs