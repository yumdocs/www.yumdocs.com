#!/bin/sh
cd "$(dirname "$0")"
node index.mjs