#!/bin/sh
cd "$(dirname "$0")"
# npm init -y
npm i typescript
npm i ts-node
npm i @yumdocs/yumdocs