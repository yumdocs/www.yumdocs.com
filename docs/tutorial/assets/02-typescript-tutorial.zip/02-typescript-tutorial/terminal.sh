#!/bin/sh
cd "$(dirname "$0")"
node --loader ts-node/esm index.ts